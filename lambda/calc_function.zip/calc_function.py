import logging

logger = logging.getLogger()
logger.setLevel(logging.INFO)

def lambda_handler(event, context):
    operator = event['action']
    param1 = event.get('param1',1)
    param2 = event.get('param2',2)

    logger.log('Received action:', operator)
    logger.log('Received param1:', param1)
    logger.log('Received param2:', param2)

    if operator == 'add':
        result = param1 + param2
    elif operator == 'sub':
        result = param1 - param2
    elif operator == 'mul':
        result = param1 * param2
    elif operator == 'div':
        result = param1 / param2
    else:
        result = 'Invalid action specified'

    logger.log('Result:', result)

    response = {'result': result}
    return response